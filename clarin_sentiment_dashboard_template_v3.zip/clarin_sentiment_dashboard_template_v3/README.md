# Clarin Sentiment Analysis — Dashboard (ES/EN)

Deploy to Hugging Face Spaces (Streamlit) or Streamlit Community Cloud.
Set `DATA_URL` for a published CSV (HF Datasets or Google Sheets), or keep `data/clarin_sentiment.csv` in the repo.
